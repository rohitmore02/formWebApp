import FormComponent from "./form";


function App() {
  return(
    <FormComponent/>
  )
}

export default App;